/*
 * File:   functiones.c
 * Author: fabio
 *
 * Created on 7 maggio 2024, 11.38
 */


#include "xc.h"
#include "functiones.h"

/*int main(void) {
    return 0;
}*/
